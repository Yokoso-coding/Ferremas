from django.db import models
from moduloCliente.models import Producto, Pedido, DetallePedido

# Create your models here.
