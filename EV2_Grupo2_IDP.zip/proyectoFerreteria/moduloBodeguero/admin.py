from django.contrib import admin
from .models import DetalleBodega

admin.site.register(DetalleBodega)
